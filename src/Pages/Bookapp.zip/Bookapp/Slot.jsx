import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Slot.css";
import { Col, Container, Row, Modal, Button, Form } from "react-bootstrap";

const Slot = () => {
  const [selectedDay, setSelectedDay] = useState("FRI 31");
  const [selectedTime, setSelectedTime] = useState("04:30 pm");
  const [showFormModal, setShowFormModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [errors, setErrors] = useState({}); // For validation errors
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    mobileNumber: "",
    date: "selectedDay",
    time: "selectedTime",
  });

  const days = [
    { day: "FRI", date: "31" },
    { day: "SAT", date: "1" },
    { day: "SUN", date: "2" },
    { day: "MON", date: "3" },
    { day: "TUE", date: "4" },
    { day: "WED", date: "5" },
    { day: "THU", date: "6" },
  ];
  const times = [
    "04:30 pm",
    "05:00 pm",
    "05:30 pm",
    "06:00 pm",
    "06:30 pm",
    "07:00 pm",
    "07:30 pm",
    "08:00 pm",
  ];

  // Function to handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Function to validate form
  const validateForm = () => {
    let newErrors = {};
    const nameRegex = /^[A-Za-z]+$/;
    const mobileRegex = /^[0-9]{10}$/;

    if (!nameRegex.test(formData.firstName)) {
      newErrors.firstName = "First Name should contain only alphabets";
    }

    if (!nameRegex.test(formData.lastName)) {
      newErrors.lastName = "Last Name should contain only alphabets";
    }

    if (!mobileRegex.test(formData.mobileNumber)) {
      newErrors.mobileNumber = "Mobile Number should be exactly 10 digits";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0; // Returns true if no errors
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      console.log("Form Submitted:", {
        ...formData,
        selectedDay,
        selectedTime,
      });
      setShowFormModal(false);
      setShowSuccessModal(true);
      setFormData({
        firstName: "",
        lastName: "",
        mobileNumber: "",
        date: selectedDay,
        time: selectedTime,
      });
      setErrors({});
    }
  };

  return (
    <>
      <Container className="text-center my-4">
        <h5 className="text-start text-custom">Booking slots</h5>

        {/* Days Selection */}
        <Row className="mt-3 justify-content-start">
          {days.map((item, index) => (
            <Col key={index} lg={1} sm={3} md={2} className="mb-2">
              <button
                className={`day-btn rounded-5 d-flex flex-column align-items-center p-2 w-100 ${
                  selectedDay === `${item.day} ${item.date}` ? "selected" : ""
                }`}
                onClick={() => setSelectedDay(`${item.day} ${item.date}`)}
              >
                <span className="day-text">{item.day}</span>
                <span className="date-text">{item.date}</span>
              </button>
            </Col>
          ))}
        </Row>

        {/* Time Selection */}
        <Row className="mt-3 justify-content-start">
          {times.map((time, index) => (
            <Col key={index} lg={2} sm={4} md={3} className="mb-2">
              <button
                className={`time-btn w-100 p-2 ${
                  selectedTime === time ? "selected" : ""
                }`}
                onClick={() => setSelectedTime(time)}
              >
                {time}
              </button>
            </Col>
          ))}
        </Row>

        {/* Book Button */}
        <div className="mt-4">
          <button
            className="book-btn px-4 py-2"
            onClick={() => {
              setFormData((prev) => ({
                ...prev,
                date: selectedDay,
                time: selectedTime,
              }));
              setShowFormModal(true);
            }}
          >
            Book an appointment
          </button>
        </div>
      </Container>

      {/* Modal for Appointment Form */}
      <Modal show={showFormModal} onHide={() => setShowFormModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title className="fw-bold">Book an Appointment</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit} className="book-form">
            <Form.Group className="mb-3">
              <Form.Label style={{ padding: "6px" }}>First Name</Form.Label>
              <Form.Control
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleInputChange}
                required
                style={{ width: "98%", margin: "auto" }}
              />
              {errors.firstName && (
                <p
                  className="text-danger bg-warning mx-auto rounded m-1"
                  style={{ width: "98%" }}
                >
                  {errors.firstName}
                </p>
              )}
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label style={{ padding: "6px" }}>Last Name</Form.Label>
              <Form.Control
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleInputChange}
                required
                style={{ width: "98%", margin: "auto" }}
              />
              {errors.lastName && (
                <p
                  className="text-danger bg-warning mx-auto rounded m-1"
                  style={{ width: "98%" }}
                >
                  {errors.lastName}
                </p>
              )}
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label style={{ padding: "6px" }}>Mobile Number</Form.Label>
              <Form.Control
                type="tel"
                name="mobileNumber"
                value={formData.mobileNumber}
                onChange={handleInputChange}
                required
                style={{ width: "98%", margin: "auto" }}
              />
              {errors.mobileNumber && (
                <p
                  className="text-danger bg-warning mx-auto rounded m-1"
                  style={{ width: "98%" }}
                >
                  {errors.mobileNumber}
                </p>
              )}
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label style={{ padding: "6px" }}>Date:</Form.Label>
              <Form.Control
                type="text"
                name="date"
                value={formData.date || ""} // Prefilled with selected day
                readOnly // Make it non-editable
                style={{ width: "98%", margin: "auto" }}
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label style={{ padding: "6px" }}>Time:</Form.Label>
              <Form.Control
                type="text"
                name="time"
                value={formData.time || ""} // Prefilled with selected time
                readOnly // Make it non-editable
                style={{ width: "98%", margin: "auto" }}
              />
            </Form.Group>

            <Button
              variant="dark"
              type="submit"
              style={{ display: "flex", justifySelf: "center" }}
            >
              Submit
            </Button>
          </Form>
        </Modal.Body>
      </Modal>

      {/* Success Modal */}
      <Modal
        show={showSuccessModal}
        onHide={() => setShowSuccessModal(false)}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title style={{ position: "relative" }}>Success</Modal.Title>
          <img
            src="\images\tick.png"
            alt=""
            style={{
              width: "90px",
              position: "absolute",
              justifySelf: "anchor-center",
              display: "flex",
              top: "-40px",
            }}
          />
        </Modal.Header>
        <Modal.Body>
          <p>Your appointment is successfully booked!</p>
          <br />
          <p>Thank You for book an appointment!</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="success" onClick={() => setShowSuccessModal(false)}>
            OK
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default Slot;
