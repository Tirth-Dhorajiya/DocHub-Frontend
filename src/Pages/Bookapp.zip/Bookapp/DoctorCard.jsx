import React from "react";
import { Button, Card, CardTitle, Col } from "react-bootstrap";
import "./DoctorCard.css";
import { Link } from "react-router-dom";

export default function DoctorCard({ dItems }) {
  return (
    <Col lg={3} md={4} sm={12} className="p-4">
      <Card className="doccard align-items-center">
        <Card.Img
          src={dItems.img}
          alt="icon"
          className="mw-100"
          style={{ objectFit: "contain", backgroundColor: "#EAEFFF" }}
        />
        <Card.Body>
          <CardTitle className="docname fw-bold" style={{ color: "#007c9d" }}>
            {dItems.name}
          </CardTitle>
          <p>{dItems.title}</p>
          <p>{dItems.hospital}</p>
          <p>{dItems.experience}</p>
          <Button>
            <Link
              style={{ color: "white", textDecoration: "none" }}
              to={`/book-appoinment/${dItems.id}`}
              state={{ doctor: dItems }}
            >
              BookNow
            </Link>
          </Button>
        </Card.Body>
      </Card>
    </Col>
  );
}
