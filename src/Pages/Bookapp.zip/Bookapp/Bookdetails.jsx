import React from "react";
import { useParams } from "react-router-dom";
import Header from "../../common/Header/Header";
import { Col, Container, Row } from "react-bootstrap";

import Slot from "./Slot";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleInfo } from "@fortawesome/free-solid-svg-icons/faCircleInfo";
import Footer from "../../common/Footer/Footer";

const doctorsData = [
  {
    id: "1",
    img: "/images/docimg/1.png",
    name: "Dr. Jane Smith",
    title: "General Physician",
    experience: "8 years",
    about:
      "Dr. Jane Smith is a highly experienced general physician dedicated to providing comprehensive primary care. She specializes in preventive healthcare, diagnosis of common illnesses, and managing chronic conditions such as diabetes and hypertension.",
    fee: "$50",
  },
  {
    id: "2",
    img: "/images/docimg/2.png",
    name: "Dr. Emily Larson",
    title: "Gynecologist",
    experience: "10 years",
    about:
      "Dr. Emily Larson is an expert gynecologist with over a decade of experience in women’s reproductive health. She specializes in prenatal care, menstrual disorders, fertility treatments, and menopause management.",
    fee: "$60",
  },
  {
    id: "3",
    img: "/images/docimg/3.png",
    name: "Dr. Michael Johnson",
    title: "Dermatologist",
    experience: "12 years",
    about:
      "Dr. Michael Johnson is a leading dermatologist specializing in skin health. He treats acne, eczema, psoriasis, and offers cosmetic dermatology services such as laser treatments and anti-aging solutions.",
    fee: "$70",
  },
  {
    id: "4",
    img: "/images/docimg/4.png",
    name: "Dr. Sophia Williams",
    title: "Pediatrician",
    experience: "9 years",
    about:
      "Dr. Sophia Williams is a compassionate pediatrician with expertise in child health. She specializes in newborn care, vaccinations, growth monitoring, and treating childhood illnesses.",
    fee: "$55",
  },
  {
    id: "5",
    img: "/images/docimg/5.png",
    name: "Dr. David Miller",
    title: "Cardiologist",
    experience: "15 years",
    about:
      "Dr. David Miller is a renowned cardiologist specializing in heart diseases. He provides expert care in hypertension, heart attacks, arrhythmias, and preventive cardiology.",
    fee: "$80",
  },
  {
    id: "6",
    img: "/images/docimg/6.png",
    name: "Dr. Olivia Brown",
    title: "Neurologist",
    experience: "14 years",
    about:
      "Dr. Olivia Brown is an experienced neurologist who specializes in brain and nervous system disorders. She treats migraines, epilepsy, strokes, and neurodegenerative diseases.",
    fee: "$90",
  },
  {
    id: "7",
    img: "/images/docimg/7.png",
    name: "Dr. Benjamin Carter",
    title: "Orthopedic Surgeon",
    experience: "11 years",
    about:
      "Dr. Benjamin Carter is an orthopedic surgeon specializing in bone and joint health. He treats fractures, arthritis, sports injuries, and performs joint replacement surgeries.",
    fee: "$75",
  },
  {
    id: "8",
    img: "/images/docimg/8.png",
    name: "Dr. Hannah Wilson",
    title: "Endocrinologist",
    experience: "10 years",
    about:
      "Dr. Hannah Wilson is an expert endocrinologist specializing in hormone-related disorders. She treats diabetes, thyroid disorders, and metabolic syndrome.",
    fee: "$70",
  },
  {
    id: "9",
    img: "/images/docimg/9.png",
    name: "Dr. Christopher Lee",
    title: "Gastroenterologist",
    experience: "13 years",
    about:
      "Dr. Christopher Lee is a skilled gastroenterologist specializing in digestive system disorders. He treats acid reflux, irritable bowel syndrome, and liver diseases.",
    fee: "$85",
  },
  {
    id: "10",
    img: "/images/docimg/10.png",
    name: "Dr. Amelia White",
    title: "Ophthalmologist",
    experience: "12 years",
    about:
      "Dr. Amelia White is an ophthalmologist specializing in eye health. She treats vision problems, cataracts, glaucoma, and performs laser eye surgeries.",
    fee: "$65",
  },
  {
    id: "11",
    img: "/images/docimg/11.png",
    name: "Dr. Daniel Green",
    title: "Psychiatrist",
    experience: "10 years",
    about:
      "Dr. Daniel Green is a psychiatrist dedicated to mental health. He treats anxiety, depression, schizophrenia, and provides counseling for stress management.",
    fee: "$75",
  },
  {
    id: "12",
    img: "/images/docimg/12.png",
    name: "Dr. Charlotte Adams",
    title: "Pulmonologist",
    experience: "11 years",
    about:
      "Dr. Charlotte Adams is a pulmonologist specializing in respiratory diseases. She treats asthma, COPD, lung infections, and sleep apnea.",
    fee: "$80",
  },
  {
    id: "13",
    img: "/images/docimg/13.png",
    name: "Dr. William Scott",
    title: "Urologist",
    experience: "14 years",
    about:
      "Dr. William Scott is a highly skilled urologist treating kidney and urinary tract disorders. He specializes in kidney stones, urinary infections, and prostate health.",
    fee: "$85",
  },
  {
    id: "14",
    img: "/images/docimg/14.png",
    name: "Dr. Jessica Thompson",
    title: "Rheumatologist",
    experience: "10 years",
    about:
      "Dr. Jessica Thompson is a rheumatologist specializing in arthritis and autoimmune diseases. She provides expert care for conditions like lupus and rheumatoid arthritis.",
    fee: "$75",
  },
  {
    id: "15",
    img: "/images/docimg/15.png",
    name: "Dr. Andrew Martinez",
    title: "Oncologist",
    experience: "16 years",
    about:
      "Dr. Andrew Martinez is an oncologist specializing in cancer treatment. He provides chemotherapy, immunotherapy, and personalized cancer care strategies.",
    fee: "$100",
  },
  {
    id: "16",
    img: "/images/docimg/16.jpeg",
    name: "Dr. Natalie Evans",
    title: "Nephrologist",
    experience: "13 years",
    about:
      "Dr. Natalie Evans is a nephrologist specializing in kidney health. She treats kidney failure, hypertension, and dialysis management.",
    fee: "$90",
  },
];
export default function Bookdetails() {
  const { id } = useParams(); // Get doctor ID from URL
  const doctor = doctorsData.find((doc) => doc.id === id);

  if (!doctor) {
    return <h2>Doctor not found</h2>;
  }

  return (
    <>
      <Header />
      <Container>
        <Row className="p-5">
          <Col lg={6} md={12} sm={12}>
            <img
              src={doctor.img}
              alt=""
              className="mw-100"
              style={{ backgroundColor: "#6c63ff" }}
            />
          </Col>
          <Col
            style={{ border: "1px solid rgb(160, 143, 143)" }}
            lg={6}
            md={12}
            sm={12}
            className="p-5 "
          >
            <h1
              className="p-1"
              style={{ color: "rgba(0, 124, 157, 0.9)", fontWeight: "bold" }}
            >
              {doctor.name}
            </h1>

            <p className="p-1">{doctor.title}</p>

            <p className="p-1">
              <strong>Experience:</strong> {doctor.experience}
            </p>

            <strong style={{ padding: "5px" }}>About</strong>
            <FontAwesomeIcon icon={faCircleInfo} />
            <p className="p-1">{doctor.about}</p>

            <p className="p-1">
              <strong>Appoinment fee:</strong> {doctor.fee}
            </p>
          </Col>
        </Row>
      </Container>
      <Slot />
      <Footer />
    </>
  );
}
